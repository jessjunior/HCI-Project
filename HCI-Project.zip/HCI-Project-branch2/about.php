<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="jquery/jquery-3.4.0.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<title>Home</title>

        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<header>
<!-- Top navigation -->
	
    	<div style="display:inline; float:left"><a href="index.php"><img src="img/logo.jpg" width="150px" height="50px"></a>
        
    </div>
    <div class="topnav">

	<!-- Centered link -->

        
        <div class="topnav-centered">
			<a href="index.php" >Home</a>
			<a href="search.php">Search</a>
			<a href="news.php">News</a>
			<a href="about.php"class="active">About</a>
			<a href="contact.php">Contact</a>
            <a href="login.php">Login</a>
		</div>
        </div>
</header>
</body>
</html>